package com.example.module2;

import androidx.lifecycle.ViewModel;

public class WasteCalculatorViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}