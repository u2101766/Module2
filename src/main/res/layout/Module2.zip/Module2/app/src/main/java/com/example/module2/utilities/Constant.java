package com.example.module2.utilities;

public class Constant {
    public static String KEY_USER_ID ="userId";
    public static String KEY_NAME ="name";
    public static String KEY_IMAGE ="image";
    public static String KEY_COLLECTION_USER ="users";
    public static String KEY_EMAIL ="email";
    public static String KEY_PASSWORD ="password";
    public static String KEY_IS_SIGNED_IN ="isSignedIn";
}
